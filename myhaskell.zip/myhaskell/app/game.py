import tkinter as tk
from tkinter import messagebox
import random

class MemoryGame:
    def __init__(self, master, width, height, symbols):
        self.master = master
        self.width = width
        self.height = height
        self.symbols = symbols
        self.board = self.create_board()
        self.buttons = []
        self.first_card = None
        self.second_card = None
        self.flipped_count = 0

        self.create_widgets()

    def create_board(self):
        num_pairs = (self.width * self.height) // 2
        symbol_list = self.symbols * num_pairs
        random.shuffle(symbol_list)
        board = []
        for _ in range(self.height):
            row = []
            for _ in range(self.width):
                symbol = symbol_list.pop()
                row.append((symbol, False))
            board.append(row)
        return board

    def create_widgets(self):
        self.frame = tk.Frame(self.master)
        self.frame.pack()

        for i in range(self.height):
            row = []
            for j in range(self.width):
                button = tk.Button(self.frame, width=5, height=2, command=lambda x=i, y=j: self.flip_card(x, y))
                button.grid(row=i, column=j)
                row.append(button)
            self.buttons.append(row)

    def flip_card(self, x, y):
        if not self.board[x][y][1] and not self.first_card:
            self.buttons[x][y].configure(text=self.board[x][y][0])
            self.board[x][y] = (self.board[x][y][0], True)
            self.first_card = (x, y)
        elif not self.board[x][y][1] and not self.second_card:
            self.buttons[x][y].configure(text=self.board[x][y][0])
            self.board[x][y] = (self.board[x][y][0], True)
            self.second_card = (x, y)
            self.master.after(1000, self.check_match)
        
    def check_match(self):
        x1, y1 = self.first_card
        x2, y2 = self.second_card
        if self.board[x1][y1][0] == self.board[x2][y2][0]:
            self.buttons[x1][y1].configure(state=tk.DISABLED)
            self.buttons[x2][y2].configure(state=tk.DISABLED)
            self.flipped_count += 2
            if self.flipped_count == self.width * self.height:
                messagebox.showinfo("Congratulations!", "You've matched all the cards!")
                self.master.quit()
        else:
            self.buttons[x1][y1].configure(text="")
            self.buttons[x2][y2].configure(text="")
            self.board[x1][y1] = (self.board[x1][y1][0], False)
            self.board[x2][y2] = (self.board[x2][y2][0], False)
        self.first_card = None
        self.second_card = None

class GameSetupWindow:
    def __init__(self):
        self.window = tk.Tk()
        self.window.title("Game Setup")
        
        self.width_label = tk.Label(self.window, text="Width:")
        self.width_label.pack()
        self.width_entry = tk.Entry(self.window)
        self.width_entry.pack()

        self.height_label = tk.Label(self.window, text="Height:")
        self.height_label.pack()
        self.height_entry = tk.Entry(self.window)
        self.height_entry.pack()

        self.symbols_label = tk.Label(self.window, text="Symbols (separated by spaces):")
        self.symbols_label.pack()
        self.symbols_entry = tk.Entry(self.window)
        self.symbols_entry.pack()

        self.start_button = tk.Button(self.window, text="Start Game", command=self.start_game)
        self.start_button.pack()

    def start_game(self):
        width = int(self.width_entry.get())
        height = int(self.height_entry.get())
        symbols = self.symbols_entry.get().split()
        self.window.destroy()
        play_memory_game(width, height, symbols)

def play_memory_game(width, height, symbols):
    root = tk.Tk()
    root.title("Memory Game")
    game = MemoryGame(root, width, height, symbols)
    root.mainloop()

# Display the game setup window
game_setup = GameSetupWindow()
game_setup.window.mainloop()
import Control.Monad (replicateM)
import System.Random (randomIO)
import Text.Read (readMaybe)


data Game = Game { 
    board :: [[Maybe Char]],
    scores :: Int,
    width :: Int,
    height :: Int,
    symbols :: [Char],
    waitTime :: Int
}

printMenu :: IO ()
printMenu = do
    putStrLn "Welcome to the Memory Game!"
    putStrLn ""
    putStrLn "1. Start new game"
    putStrLn "2. Scores"
    putStrLn "3. Guide"
    putStrLn "4. Quit"
    putStrLn ""
    putStrLn "Enter your choice:"

gameLoop :: IO ()
gameLoop = do
    printMenu
    choice <- getLine
    case choice of
        "1" -> do
            putStrLn "Enter width, height, number of symbols, and wait time:"
            input <- getLine
            let inputs = words input
            case inputs of
                [w, h, k, t] -> do
                    let maybeWidth = readMaybe w :: Maybe Int
                        maybeHeight = readMaybe h :: Maybe Int
                        maybeSymbols = readMaybe k :: Maybe Int
                        maybeWaitTime = readMaybe t :: Maybe Int
                    case (maybeWidth, maybeHeight, maybeSymbols, maybeWaitTime) of
                        (Just width, Just height, Just symbols, Just waitTime) -> do
                            symbolList <- replicateM symbols randomIO
                            let game = Game (replicate height (replicate width Nothing)) 0 width height symbolList waitTime
                            startNewGame game
                        _ -> do
                            putStrLn "Invalid input. Please try again."
                            gameLoop
                _ -> do
                    putStrLn "Invalid input format. Please try again."
                    gameLoop
        "2" -> do
            putStrLn "Displaying scores..."
            -- Display the scores
            gameLoop
        "3" -> do
            putStrLn "Displaying guide..."
            -- Display the game guide
            gameLoop
        "4" -> do
            putStrLn "Quitting the game. Goodbye!"
        _ -> do
            putStrLn "Invalid choice. Please try again."
            gameLoop

startNewGame :: Game -> IO ()
startNewGame game = do
    putStrLn "Starting a new game..."
    putStrLn "Guess the correct symbol to earn points. You have 5 attempts."
    gameLogic game 5  -- Start the game with 5 attempts

gameLogic :: Game -> Int -> IO ()
gameLogic game attempts = do
    if attempts == 0
        then do
            putStrLn "Game over. You've used all your attempts."
            gameLoop
        else do
            putStrLn "Enter your guess:"
            guess <- getLine
            if guess == [head (symbols game)]
                then do
                    putStrLn "Correct! You've earned a point."
                    let newScore = (scores game) + 1
                    let newGame = game { scores = newScore }
                    gameLogic newGame attempts
                else do
                    putStrLn "Incorrect. Try again."
                    gameLogic game (attempts - 1)

main :: IO ()
main = do
    putStrLn "Starting the Memory Game..."
    gameLoop


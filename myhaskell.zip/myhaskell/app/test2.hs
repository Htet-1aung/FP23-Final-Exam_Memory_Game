import System.Random
import Web.Scotty
import Control.Monad
import Control.Monad.State
import Data.List
import Text.Printf
import Data.Array.IO (IOArray, readArray, writeArray, newListArray)



type Card = (Char, Bool)
type Board = [[Card]]

createBoard :: Int -> Int -> [Char] -> IO Board
createBoard width height symbols = do
    let numPairs = (width * height) `div` 2
    let symbolList = concat $ replicate numPairs symbols
    shuffledSymbols <- shuffle symbolList
    let board = [ [ (symbol, False) | symbol <- take width rest ]
                | rest <- splitEvery width shuffledSymbols ]
    return board
-- Randomly shuffle a list
--   /!\    This function is not very efficient (quadratic complexity)
shuffle :: [a] -> IO [a]
shuffle xs = do
    ar <- newArray n xs
    forM [1..n] $ \i -> do
        j <- randomRIO (i,n)
        vi <- readArray ar i
        vj <- readArray ar j
        writeArray ar j vi
        return vj
  where
    n = length xs
    newArray :: Int -> [a] -> IO (IOArray Int a)
    newArray n xs =  newListArray (1,n) xs

-- Splits a list into sublists of length n
-- The last sublist will be shorter if n does not evenly divide the length of the list.
splitEvery :: Int -> [a] -> [[a]]
splitEvery _ [] = []
splitEvery n xs = as : splitEvery n bs
  where
    (as,bs) = splitAt n xs

-- Replaces the element at the given position in a two-dimensional list
replace2D :: Int -> Int -> a -> [[a]] -> [[a]]
replace2D x y z = map (\(i,row) -> map (\(j,val) -> if i == y && j == x then z else val) (zip [0..] row)) . zip [0..]

printBoard :: Board -> IO ()
printBoard board = do
    forM_ board $ \row -> do
        forM_ row $ \(symbol, flipped) -> do
            putStr $ if flipped then [symbol] else "*"
            putStr " "
        putStrLn ""

getInput :: Int -> Int -> IO (Int, Int)
getInput width height = do
    putStrLn "Enter the x-coordinate (0 to width-1): "
    x <- readLn
    putStrLn "Enter the y-coordinate (0 to height-1): "
    y <- readLn
    if x < 0 || x >= width || y < 0 || y >= height
        then do
            putStrLn "Invalid input. Please try again."
            getInput width height
        else return (x, y)

updateBoard :: Board -> Int -> Int -> Int -> Int -> Board
updateBoard board x1 y1 x2 y2 =
    if (symbol1 == symbol2)
        then replace2D y1 x1 (symbol1, True) $ replace2D y2 x2 (symbol2, True) board
        else board
    where
        (symbol1, _) = board !! y1 !! x1
        (symbol2, _) = board !! y2 !! x2

checkGameOver :: Board -> Bool
checkGameOver = all (all snd)

playMemoryGame :: IO ()
playMemoryGame = do
    putStrLn "Welcome to the Memory Game!"

    putStrLn "Enter the width of the board: "
    width <- readLn
    putStrLn "Enter the height of the board: "
    height <- readLn
    putStrLn "Enter the symbols to use (separated by a space): "
    symbols <- getLine
    
    board <- createBoard width height (unwords (words symbols))

    --board <- createBoard width height (words symbols)

    gameLoop board

    putStrLn "\nThanks for playing!"

gameLoop :: Board -> IO ()
gameLoop board = do
    putStrLn "\nCurrent board:"
    printBoard board

    putStrLn "\nChoose the first card:"
    (x1, y1) <- getInput (length (head board)) (length board)
    let board' = replace2D y1 x1 ((fst (board !! y1 !! x1)), True) board

    putStrLn "\nCurrent board:"
    printBoard board'

    putStrLn "\nChoose the second card:"
    (x2, y2) <- getInput (length (head board')) (length board')
    let board'' = replace2D y2 x2 ((fst (board' !! y2 !! x2)), True) board'

    putStrLn "\nCurrent board:"
    printBoard board''

    let board''' = updateBoard board'' x1 y1 x2 y2
    if (board'' == board''')
        then putStrLn "No match."
        else putStrLn "Match!"

    if checkGameOver board'''
        then putStrLn "\nCongratulations! You've matched all the cards!"
        else gameLoop board'''

main :: IO ()
main = scotty 3000 $ do
    get "/" $ do
        liftIO playMemoryGame
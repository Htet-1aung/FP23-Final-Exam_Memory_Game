import React, { useState } from 'react';

const Game = () => {
    const [game, setGame] = useState({
        board: [],
        scores: 0,
        width: 0,
        height: 0,
        symbols: [],
        waitTime: 0
    });

    const startNewGame = (w, h, k, t) => {
        // Generate symbols here
        let symbols = [];
        for(let i=0; i<k; i++) {
            symbols.push(String.fromCharCode(Math.floor(Math.random() * 26) + 65));
        }

        let board = Array(w).fill().map(() => Array(h).fill(null));
        setGame({ board: board, width: w, height: h, symbols: symbols, waitTime: t });
    };

    const printScores = () => {
        alert(`Your score: ${game.scores}`);
    };

    const printGuide = () => {
        alert("This is a memory game. You will be presented with a grid of hidden symbols...");
        // Add more instructions here
    };

    return (
        <div>
            <h1>Welcome to the Memory Game!</h1>
            <button onClick={() => startNewGame(5, 5, 5, 5)}>Start new game</button>
            <button onClick={printScores}>Scores</button>
            <button onClick={printGuide}>Guide</button>
            <button onClick={() => alert("Thanks for playing!")}>Quit</button>
        </div>
    );
};

export default Game;
